import { Component, OnInit } from '@angular/core';
import { SideNavService } from 'src/app/service/side-nav.service';
import { Store } from '@ngrx/store';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import * as eventsActions from '../../store/actions/event';
import { SnackBarService } from 'src/app/service/snack-bar.service';
import { Item } from 'src/app/store/model/event.model';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor(
    private store: Store<any>,
    private sideNavService: SideNavService,
    private snackBarService: SnackBarService,
    private formBuilder: FormBuilder) {
      this.searchForm = this.formBuilder.group({
        searchText: new FormControl('')
      });
    }

  selectedItem: Item;
  searchForm: FormGroup;
  sideNav = true;
  openSideNavState = false;
  userInfo = {
    user : {
      fullName: 'Pappu Sharma',
      emailID: 'pappu231092sharma@gmail.com',
      phoneNumber: '8374708931'
    }
  };

  ngOnInit() {

    this.store.subscribe(store => {
      this.selectedItem = { ...store.ItemList.selectedItem };
    });

    this.sideNavService.sideNavUpdated.subscribe(enableMenu => {
      this.sideNav = enableMenu;
    });

    this.onTextChange();
  }

  addNewItem() {
    this.store.dispatch(new eventsActions.AddNewItem());
    this.snackBarService.open('New Item Added', '', {
      type: 'success'
    });
  }

  deleteSelectedItem() {
    if (this.selectedItem && this.selectedItem.id) {
      this.store.dispatch(new eventsActions.DeleteItem());
      this.snackBarService.open('Item Deleted', '', {
        type: 'success'
      });
    } else {
      this.snackBarService.open('Select Item First', '', {
        type: 'warning'
      });
    }
  }

  onTextChange(): void {
    this.searchForm.get('searchText').valueChanges.subscribe(val => {
      console.log(val);
      this.sideNavService.textChange(val);
    });
  }

  toggleSideNav() {
  }

  setSideNavState() {
    this.sideNav = !this.sideNav;
    const element = document.getElementById('sidenav');
    if (this.sideNav) {
      element.classList.remove('menu-hide');
    } else {
      element.classList.add('menu-hide');
    }
    this.sideNavService.setSideNavState(this.sideNav);
  }

  functionalityNotAdded() {
    this.snackBarService.open('Functionality Not Added Yet', '', {
      type: 'warning'
    });
  }

  // tslint:disable-next-line:use-lifecycle-interface
  ngAfterViewInit() {
    if (window.innerWidth <= 1024) {
      this.sideNav = !this.sideNav;
      this.sideNavService.setSideNavState(this.sideNav);
    }
  }
}
