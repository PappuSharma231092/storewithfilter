import { Component, OnInit } from '@angular/core';
import { SideNavService } from 'src/app/service/side-nav.service';
import { Item } from 'src/app/store/model/event.model';
import { Store } from '@ngrx/store';
import * as eventsActions from '../../store/actions/event';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent implements OnInit {

  sideNavContentList: Item[] = [];
  selectedItem: Item;
  searchText = '';

  openSideNavState = false;

  sidenavState: any;
  sideNav: boolean;

  constructor(
    private store: Store<any>,
    private sideNavService: SideNavService) {

  }

  ngOnInit() {
    this.sidenavState = this.sideNavService.getSideNavState().event;
    this.mobileScreenSidenav();
    this.store.subscribe(store => {
      console.log(store);
      this.sideNavContentList = store.ItemList.dataList;
      this.selectedItem = store.ItemList.selectedItem;
    });

    this.sideNavService.text$.subscribe(text => {
      this.searchText = text;
    });
  }

  mobileScreenSidenav() {
    if (screen.width <= 1024) {
      this.sideNavService.setSideNavState(false);
    }
  }

  selectList(index) {
    this.store.dispatch(new eventsActions.SelectItem(this.sideNavContentList[index]));
  }

  toggle() {
    const element = document.getElementById('sidenav');
    element.classList.add('menu-hide');
    this.sideNavService.setSideNavState(false);
  }


}
