import * as eventActions from '../actions/event';

const initialState: any = {
  dataList: [{
    id: '1',
    subHeader: 'home',
    description: 'home'
  }, {
      id: '2',
      subHeader: 'about',
      description: 'info'
    }, {
      id: '3',
      subHeader: 'contact',
      description: 'perm_contact_calendar'
    }],
  selectedItem: {}
};

export function EventReducer(state = initialState, action: eventActions.ItemActions) {
  switch (action.type) {
    case eventActions.ADD_NEW_ITEM: {
      const newItem = {
        id: Math.floor((1 + Math.random()) * 0x10000)
          .toString(16)
          .substring(1),
        subHeader: 'New Item',
        description: 'Just new item inserted'
      };
      const listItem = [{...newItem}, ...state.dataList];
      state = { ...state, selectedItem: { ...newItem } };
      state.selectedItem = { ...newItem };
      state.dataList = [ ...listItem ];
      return state;
    }
    case eventActions.UPDATE_SELECTED_ITEM: {
      const dataList = [...state.dataList];
      const selItem = { ...state.selectedItem };
      if (selItem && selItem.id) {
        const index = dataList.findIndex(x => x.id === selItem.id);
        if (index !== -1) {
          selItem.subHeader = action.payload;
          dataList[index] = { ...selItem };
        }
        state = { ...state, selectedItem: {...selItem}, dataList: [ ...dataList]};
      }
      return state;
    }

    case eventActions.DELETE_ITEM: {
      let dataList = [...state.dataList];
      const selItem = { ...state.selectedItem };
      if (selItem && selItem.id) {
        dataList = dataList.filter(x => x.id !== selItem.id);
        state = { ...state, selectedItem: {}, dataList: [...dataList] };
      }
      return state;
    }
    case eventActions.SELECT_ITEM: {
      state = { ...state, selectedItem: { ...action.payload } };
      return state;
    }

    default: {
      return state;
    }
  }
}
