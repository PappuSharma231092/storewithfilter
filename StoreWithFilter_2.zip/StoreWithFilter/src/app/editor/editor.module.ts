import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TextEditorComponent } from './text-editor/text-editor.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DemoMaterialModule } from '../material-module/material-module.module';
import { StoreModule } from '@ngrx/store';
import { EventReducer } from '../store/reducers/event';



@NgModule({
  declarations: [TextEditorComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DemoMaterialModule,
    StoreModule.forFeature('ItemList', EventReducer)
  ],
  exports: [TextEditorComponent]
})
export class EditorModule { }
