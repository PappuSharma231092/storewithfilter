import { Injectable } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';

@Injectable()
export class SnackBarService {
    static panelClass = {
        success: ['toast-success'],
        error: ['toast-error'],
        warning: ['toast-warning']
    };

    private toastConfig: MatSnackBarConfig = {
        duration: 2000,
        panelClass: [],
        verticalPosition: 'top',
        horizontalPosition: 'end'
    };

    constructor(private snackBar: MatSnackBar) { }

    open(message: string, action: string, config?) {
        if (config) {
            const type = config.type || '';
            if (type && SnackBarService.panelClass.hasOwnProperty(type)) {
                this.toastConfig.panelClass = SnackBarService.panelClass[type];
            }
            this.toastConfig.duration = config.duration || 2000;
        }
        this.snackBar.open(message, action, this.toastConfig);
    }

    close() {
        this.snackBar.dismiss();
    }
}
