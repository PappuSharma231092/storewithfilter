import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { DemoMaterialModule } from '../material-module/material-module.module';
import { RouterModule, Routes } from '@angular/router';
import { TextEditorComponent } from '../editor/text-editor/text-editor.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { EventReducer } from '../store/reducers/event';
import { SideNavService } from '../service/side-nav.service';
import { FilterPipe } from '../pipe/filter.pipe';

const routes: Routes = [
  { path: '', component: TextEditorComponent },
  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    HeaderComponent, SidenavComponent, FilterPipe
  ],
  imports: [
    CommonModule,
    DemoMaterialModule,
    // RouterModule,
    RouterModule.forRoot(routes),
    FormsModule,
    ReactiveFormsModule,
    DemoMaterialModule,
    // Without this declaration it throws ReducerManager error
    StoreModule.forFeature('ItemList', EventReducer)
  ],
  exports: [HeaderComponent, SidenavComponent],
  providers: [SideNavService]
})
export class SharedModule { }
