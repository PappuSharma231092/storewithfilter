
import { Item } from '../model/event.model';

export const ADD_NEW_ITEM = 'ADD_NEW_ITEM';
export const UPDATE_SELECTED_ITEM = 'UPDATE_SELECTED_ITEM';
export const DELETE_ITEM = 'DELETE_ITEM';
export const SELECT_ITEM = 'SELECT_ITEM';

export class AddNewItem {
  type = ADD_NEW_ITEM;
  constructor(public payload: any = null) { }
}


export class UpdateSelectedItem {
  type = UPDATE_SELECTED_ITEM;
  constructor(public payload: any) { }
}

export class DeleteItem {
  type = DELETE_ITEM;
  constructor(public payload: any = null) { }
}

export class SelectItem {
  type = SELECT_ITEM;
  constructor(public payload: any) { }
}

export type ItemActions =
  | AddNewItem
  | UpdateSelectedItem
  | DeleteItem
  | SelectItem;
