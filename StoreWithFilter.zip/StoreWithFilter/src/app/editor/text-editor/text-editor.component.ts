import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Item } from 'src/app/store/model/event.model';
import * as eventsActions from '../../store/actions/event';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-text-editor',
  templateUrl: './text-editor.component.html',
  styleUrls: ['./text-editor.component.scss']
})
export class TextEditorComponent implements OnInit {

  constructor(
    private store: Store,
    private formBuilder: FormBuilder) {
    this.textBoxForm = this.formBuilder.group({
      text_box: new FormControl('')
    });
   }

  toDay = new Date();
  textBoxForm: FormGroup;
  selectedItem: Item;

  ngOnInit(): void {
    this.store.subscribe(store => {
      console.log(store);
      this.selectedItem = { ...store.ItemList.selectedItem };
      if (this.selectedItem && this.selectedItem.id) {
        this.textBoxForm.setValue({
          text_box: this.selectedItem.subHeader
        });
      }
      if (this.textBoxForm.value.text_box && this.selectedItem && this.selectedItem.id === undefined) {
        this.textBoxForm.setValue({
          text_box: ''
        });
      }
    });
    this.onTextChange();
  }

  onTextChange(): void {
    this.textBoxForm.get('text_box').valueChanges.subscribe(val => {
      console.log(val);
      if (this.selectedItem && this.selectedItem.subHeader !== val) {
        this.store.dispatch(new eventsActions.UpdateSelectedItem(val));
      }
    });
  }

}
