import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DemoMaterialModule } from './material-module/material-module.module';
// import { HeaderComponent } from './shared/header/header.component';
// import { SidenavComponent } from './shared/sidenav/sidenav.component';
import { SideNavService } from './service/side-nav.service';
import { SharedModule } from './shared/shared.module';
import { EditorModule } from './editor/editor.module';
import { StoreModule } from '@ngrx/store';
import { EventReducer } from './store/reducers/event';
import { SnackBarService } from './service/snack-bar.service';

@NgModule({
  declarations: [
    AppComponent,
    // HeaderComponent,
    // SidenavComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    SharedModule,
    EditorModule,
    StoreModule.forRoot({})

  ],
  providers: [SideNavService, SnackBarService],
  bootstrap: [AppComponent]
})
export class AppModule { }
