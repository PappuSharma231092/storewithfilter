import { Injectable, EventEmitter } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class SideNavService {
    private sideNav: boolean;
    sideNavUpdated = new EventEmitter();
    searchText = new BehaviorSubject('');

    text$ = this.searchText.asObservable();

    constructor() { }

    textChange(text) {
        this.searchText.next(text);
    }

    getSideNavState() {
        return {
            value: this.sideNav,
            event: this.sideNavUpdated
        };
    }

    setSideNavState(state) {
        this.sideNav = state;
        this.sideNavUpdated.emit(this.sideNav);
    }
}
